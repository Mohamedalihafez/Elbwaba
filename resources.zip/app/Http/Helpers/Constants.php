<?php 

define('SUPERADMIN',1);
define('USER',2);
define('OWNER',3);



