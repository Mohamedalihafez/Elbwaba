<?php 

require 'AsideHelper.php';
require 'forgetpassword.php';
require 'Constants.php';
require 'Priviledges.php';