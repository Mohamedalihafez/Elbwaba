<?php 

define('ALL_PREVLIEGE', 1);

//Advertisement 
define('VIEW_ADVERTISEMENT', 4);
define('UPSERT_ADVERTISEMENT', 5);
define('DELETE_ADVERTISEMENT', 6);
